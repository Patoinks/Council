# Code and existing timing evidence — scope-corrected v5

The target is the chess AI's complete-games-per-second capability. Existing arena/group/evolution scripts are adjacent caller evidence, not an instruction to optimize tournaments or their selection/scoring/scheduling process. The exact tournament invocation is not a prerequisite and must not be requested from Martim.

The source snapshot contains 178 selected local Python/C++ files, captured from the existing dirty working tree and frozen G4 Leto Python reference. The source bytes and hashes are unchanged from the earlier capture; the question and evidence interpretation are corrected here. No earlier Council answer, proposal, review, synthesis or decree is included.

`historical-per-game-thinking-times.csv` mechanically extracts 440 timing entries from three existing Claudio result files, with original-file hashes in `timing-provenance.json`. These are recorded per-player decision/thinking durations in completed or capped games, not end-to-end game wall times. They are historical measurements, not claims of the current engine's observed throughput. No new benchmark or game was run. Use them carefully as evidence for an explicit theoretical cost model; do not turn the reciprocal of partial thinking time into measured complete-game throughput.

The latest evolution JSON files inspected on disk do not contain a full invocation or per-game wall-time log; they belong to an adjacent CognitiveAgent path. Their absence does not prevent the best theoretical engine plan. State assumptions and estimate full-game cost from the code and supplied timing components. Do not reduce the answer to “unknown” or demand a new benchmark first.

`claudio-ESTADO.md` is retained as original project-rule/source history. Its prohibition on Gepeto inspection still applies. Its six-worker note is not a requirement or criterion of this Council: the metric is architectural speed per worker at fixed resources, as Martim clarified. No live worker/priority setting or training process is changed.
