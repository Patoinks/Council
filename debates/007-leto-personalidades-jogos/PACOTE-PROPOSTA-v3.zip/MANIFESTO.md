# Manifest — Local Leto mutation-tournament throughput and personalities, fresh cycle

- **Debate:** 007-leto-personalidades-jogos.
- **Date:** 2026-10-17 Europe/Lisbon.
- **Context:** `CONTEXTO.md` v3; local Python/C++ target, source-only package and constraints as recorded there.
- **Governance:** root `LEIS.md` Laws No. 1–4 and `REGRAS.md` v2.1 embedded in each packet.
- **Source package:** `PACOTE-PROPOSTA-v3.zip`; source inventory is inside; package digest in `PACOTES.sha256`.
- **Proposal marker:** `END-OF-PACKET-007-PROPOSAL-v3`.
- **Review packet:** prepared only after closure of the proposal set.
- **No GitHub publication, benchmark, tournament, training, account change or source implementation.**
- **Protected exclusions:** no `scripts/group_stage.py`, `Gepeto/`, weights, checkpoints, binaries, tournament outputs, credentials, tokens or `.env`.

## Independence and roles

All requested advisers are Sol, GPT-6 Normal, Argon, Sonnet and Astra; Opus is King, not a participant. Prior 007 proposals/reviews are historical and are excluded from the new closed sets. Sol is both operator and disclosed adviser; it has prior exposure to old 007 materials and will declare that. Every other contribution records model visibility, actual tools, memory, exposure and whether it is a new conversation/execution. All proposals use the same packet. No peer proposal is shared before closure.

## Availability rule

Attempt all five requested advisers anew for each phase. Under Law No. 4, immediately skip a participant on quota/credit absence or UI/CLI/model bug, recording the participant, phase, interface, timestamp and exact error. Do not wait, substitute or ask Martim to decide. A late contribution remains an addendum outside the closed set.

## Proposal receipts

| ID | Interface/session | Status | Receipt / error |
|---|---|---|---|
| sol | Pending | Pending | Pending |
| normal | Pending | Pending | Pending |
| argon | Pending | Pending | Pending |
| sonnet | Pending | Pending | Pending |
| astra | Pending | Pending | Pending |
