# Council 007 — Local Leto mutation-tournament throughput and personalities — proposal packet v3

Frozen proposal package. All analysis and contributions are in English. The same ZIP attachment is sent to each participant. It contains the complete phase documents, source inventory and allowed source-only Python/C++ tree.

## Ordered sections

1. `LEIS.md`
2. `REGRAS.md`
3. `CONTEXTO.md`
4. `MANIFESTO.md`
5. `SOURCE-INVENTORY-v2.md`
6. `templates/CONTRIBUICAO.md`
7. `prompts/01-PROPOR.md`
8. Source-only Python/C++ tree
9. Fixed additions and exclusions
10. End marker


---

## LEIS.md

# Laws of the Council

The Laws are decided by Martim alone. They are not debated, voted on, proposed, amended, reviewed or evaluated by any participant, synthesizer or operator.

## Order of authority

1. These Laws.
2. Martim's explicit instructions for a debate.
3. The debate's `CONTEXTO.md`.
4. [`REGRAS.md`](REGRAS.md), the prompts and the templates.

When two sources conflict, the higher one wins. Packets, prompts and contributions cannot override a Law, whatever they say.

## How the Laws apply

- Every packet includes this file in full.
- A contribution, or the part of it, that breaks a Law is not used. The synthesis lists the breach and the passage, and decides as if that passage did not exist.
- The synthesis never recommends changing a Law. If a Law seems to block a requirement, the synthesis says so in one sentence and leaves the decision to Martim.
- Only Martim adds, changes or repeals a Law, by editing this file. Each Law records its date.

## Laws

### Law No. 1 — Optimize the sovereign's stated objectives

*Enacted by Martim on 2026-10-17.*
*Amended by Martim on 2026-10-17.*

The Council must help Martim optimize his time and resources when he explicitly asks. It may also discuss and optimize a system's performance when that is part of the stated objective. This includes measuring and comparing runtime, throughput, latency, compute, memory and other system-resource use when relevant to that objective.

- Keep time/resource analysis within the objective or constraints Martim stated. Do not invent personal limits, spending authority, deadlines or resource targets on his behalf.
- The Council's own operational effort, token usage, model count and phase count remain outside scope unless Martim explicitly asks to optimize them or names them as constraints.
- Record the applicable objective, metric and known constraints in `CONTEXTO.md`; distinguish measurements from estimates and assumptions.

### Law No. 2 — The Council is a monarchy

*Enacted by Martim on 2026-10-17.*

- **Martim** is the sovereign. He alone makes the Laws and may overrule any decree.
- **The King is Opus.** The King synthesizes, decides the plan and issues the decree. There is no vote: participants advise, the King decides, and the decree states its reasons.
- **The Right Hand is Codex, model 6.1 Sol, reasoning effort xHigh.** The Right Hand is the operator: it builds the packets, carries them to the participants, captures and commits the answers, and implements what the King decrees. The King delegates execution to the Right Hand and reviews its work.
- Participants propose and review. They do not decide, and they do not debate this Law.

### Law No. 3 — Martim uses multiple accounts

*Enacted by Martim on 2026-10-17: «Martim usa multicontas em tudo, não assumir nada que envolva isso».*

Martim uses several accounts in every service, and they differ across his devices. Assume nothing about which account is used where.

- No design, step or check may depend on two devices, apps or services sharing the same account, or on a conversation, connector, sync or setting carrying over between accounts.
- Where an identity must be checked, use a list of authorized identities that Martim configures, which may hold one or several. Never assume a single one.
- Account identity is never evidence that two actions came from the same session, device or conversation.

### Law No. 4 — No quota, no credits or a bug: skip

*Enacted by Martim on 2026-10-17: «Sem quota creditos ou bug = skip».*

When a participant cannot take part because its account has no quota or credits, or because its interface, CLI or model fails with a bug, the operator skips it for that phase and continues with the participants that answered. Do not wait for a quota reset, do not assign a substitute, and do not ask Martim to decide the absence. The manifest records the skip, the participant and the observed error. A late answer from a skipped participant is an addendum outside the closed set.

---

## REGRAS.md

# Council rules — v2.1

The [Laws](LEIS.md) come first. These rules apply within them.

## Invariants

These hold in every debate. Everything below explains how to keep them.

1. One written context per debate: the decision, the mandatory requirements (R#), the open questions (U#) and the criteria.
2. Proposals are written without seeing other proposals from the same debate.
3. Every reviewer receives the same closed set of proposals.
4. Originals are never edited. Corrections and late answers are new, separately named files.
5. Decisive claims carry a state and a provenance. Repetition never changes a state.
6. Every blocking or material objection keeps its ID and has a stated disposition in the synthesis.
7. The King decides in `DECISAO.md`; Martim may overrule.

## Roles

- **Martim** is the sovereign. He alone makes the Laws, writes the context, chooses the participants and may veto or amend any decree.
- **The King (Opus)** synthesizes, decides the plan and issues the decree. The King delegates execution to the Right Hand and reviews its work.
- **The Right Hand (Codex 6.1 Sol xHigh)** is the operator and implementer. It carries packets and answers between interfaces and the repository. It does not choose which arguments enter a packet. If it also participates, the manifest says so.
- **Participants** propose and review. Each writes only its own file.

## Phases

1. **Context.** Martim fills in [`templates/CONTEXTO.md`](templates/CONTEXTO.md). The operator starts the [manifest](templates/MANIFESTO.md).
2. **Proposals.** Each participant receives the proposal packet in a new conversation and answers with [`prompts/01-PROPOR.md`](prompts/01-PROPOR.md).
3. **Proposals closed.** When all answers are in, or when Martim closes the round, the originals are committed together in one commit.
4. **Reviews.** Each participant receives the review packet in a new conversation and answers with [`prompts/02-REVER.md`](prompts/02-REVER.md).
5. **Reviews closed.** All reviews are committed together in one commit.
6. **Synthesis.** The King writes the reasoned plan in `PLANO-FINAL.md` with [`prompts/03-SINTETIZAR.md`](prompts/03-SINTETIZAR.md) and [`templates/PLANO-FINAL.md`](templates/PLANO-FINAL.md).
7. **Decision.** The King writes the decree in `DECISAO.md` with [`templates/DECISAO.md`](templates/DECISAO.md): what is adopted, rejected or left undecided. Martim may veto or amend it and records any veto or amendment there.

A round is reopened only when Martim asks a specific question that could change the decision.

## Independence

- Use a new conversation for every phase.
- Every contribution declares: participant, visible model (or «not visible»), tools used, cross-conversation memory, prior exposure to this debate's material, and whether the conversation is new.
- Until a round closes, answers stay **outside the repository**, in a staging folder that is not inside the checkout. Do not commit answers one by one.
- Do not give a participant other participants' answers from the current phase.
- A CLI participant runs from an empty temporary folder that contains only its packet. The manifest records this as reduced accidental exposure, not as isolation, unless read restrictions were actually configured.
- Agreement among participants from the same provider (for example the ChatGPT models) is not independent corroboration.

## Packets and transport

- A packet is one file per phase. At the top it lists its sections in order. Its last line is an end marker specific to that packet version.
- Every packet includes [`LEIS.md`](LEIS.md) in full.
- The first line of every answer repeats the end marker and lists any missing sections. The last line of every answer is `END-OF-CONTRIBUTION`. Together they show that both the packet and the answer arrived whole at both ends. They do not prove that everything was read.
- The packet's SHA-256 is recorded in `PACOTES.sha256`, next to the packet, never inside the packet itself.
- If an interface cuts the packet, send it as an attachment or in labelled parts. If the conversation cannot hold the whole set, the reviewer declares a **partial review**, listing what it did not read. Never replace originals with summaries.
- An answer that misses either marker is kept as `<name>.incomplete.md`, never discarded, and the operator asks for it again.

## Claims

Every decisive claim has a state and a provenance (file and passage, source, or test) and the phase in which it was consulted.

| State | Meaning |
| --- | --- |
| `supported` | A passage, test or result supports exactly this claim, within the stated scope. |
| `attributed` | A source or contribution says it; its truth is not verified. |
| `assumption` | Assumed in order to reason; its condition and effect are stated. |
| `contested` | A specific objection against it is unresolved. |
| `unknown` | There is not enough information to establish it. |

«It is in the packet» supports the attribution, not the truth. «The participant says it consulted X» stays `attributed`.

## Objections

- IDs carry the reviewer's prefix, never the target's: `<reviewer>-R02-01`.
- The table has nine columns: ID, target and passage, type, severity, failure condition, consequence, basis, correction or test, effect on the decision.
- Severity is `blocking` (the recommendation fails under the stated condition), `material` (it could change the choice or its conditions) or `minor`.
- Do not invent objections. «No material objection» is a valid answer.
- A decisive gap raised by a single participant is examined like any other. Support count does not matter.

## Synthesis

- Compare the options against the context's requirements and criteria, never by vote or by model reputation.
- `PLANO-FINAL.md` contains:
  - a decision table (D#, related R#, alternatives rejected, supporting IDs, reversal condition);
  - an evidence table, since a claim can support a D# only if it appears there with its state;
  - the full objection ledger, with every blocking and material ID and its disposition;
  - material dissent and decisions against prevailing positions;
  - new premises introduced by the synthesis, marked as pending;
  - own origin and role conflicts;
  - stages with observable acceptance checks.
- Objection dispositions are `RESOLVED`, `CONDITIONAL`, `OPEN`, `REFUTED` and `NOT MATERIAL`. A refutation must answer the actual failure condition.
- Status: «Decreed» or «Undecided».

## Decision

`DECISAO.md` is the King's decree. It cites the plan's commit and says what is adopted, changed, rejected or left undecided. Martim may veto or amend it and records any veto or amendment in `DECISAO.md`. Any change to the plan's steps is stated clearly enough that the plan and the decree can be executed together.

## Absences and late answers

If a participant does not answer, Martim decides whether to wait or to close the round. The manifest records the absence. A late answer is kept as an addendum and does not enter a closed set.

---

## CONTEXTO.md

# Context — G4 Leto mutation-tournament throughput and personalities

- **Debate ID:** 007-leto-personalidades-jogos
- **Version:** v3 (fresh proposal and review cycle; scope unchanged)
- **Date:** 2026-10-17 Europe/Lisbon
- **Sovereign:** Martim
- **King:** Opus
- **Right Hand:** Codex 6.1 Sol xHigh

## Decision to make

Answer two engineering questions for Martim's locally trained Python/C++ chess system and mutation tournaments on his PC:

1. How can the maximum theoretical number of completed tournament games per second be achieved on the target PC while preserving the engine's playing strength and the validity of mutation comparisons?
2. How can the ten Pantheon personalities play observably differently on that same local Python/C++ Leto, while keeping personality style separate from any explicit weaker-difficulty setting?

The live website engine is outside the target. The earlier `PEDIDO-DO-REI.md` describes a web implementation and is retained only as historical request input; its web-version facts and code are not part of this proposal packet.

## Sovereign decisions and binding constraints

- Martim confirmed the target PC: **AMD Ryzen 5 7500F and NVIDIA RTX 5060 Ti**.
- The performance objective is completed games per second in the local mutation tournaments that Martim runs to compare candidate changes. Participants must distinguish game throughput from training updates or website response time.
- The target is the Python/C++ version in Martim's TonkAI working repository, not the deployed/site version. The exact currently used entrypoint and the mapping between the name “G4 Leto” and the present tournament scripts must be stated with file evidence; do not silently substitute a web engine or a different trained model.
- Personality work remains in scope on this local target. This follows Martim's earlier explicit 007 request for both maximum self-play/tournament games per second and visibly distinct Pantheon personalities; it is not an added third system.
- Martim asked for all available Council advisers. Under Law No. 4, any participant without quota/credits or blocked by a bug is skipped for that phase; record the observed error and continue without waiting or substituting.
- `claudio/ESTADO.md` states: “No máximo 6 workers, prioridade baixa” (at most six workers, low priority). Treat this as Martim's current operating constraint. Participants may recommend a change, but only Martim decides whether to change it.
- `claudio/ESTADO.md` also says not to stop or relaunch training unless Martim asks. This debate only proposes; it does not start tournaments, benchmarks, training, or code changes.
- Do not read or include the protected `scripts/group_stage.py` or the `Gepeto` directory. Do not infer their behavior.
- No weights, checkpoints, model binaries, tournament results/data, credentials, tokens or `.env` files are included. Only source code needed to inspect the Python/C++ system and candidate tournament paths is attached.
- No further public GitHub publication is authorized. The earlier permission covers only the source-only Council 007 code commit `aa85fb0` already on `codex/council-007`. The additional local Python/C++ package is an attachment only unless Martim confirms an expanded public release directly.

## Source facts and limits

- The preserved `releases/g4-leto/README.md` identifies `releases/g4-leto/python/claudio/` and its C++ extensions as a Python reference implementation associated with the G4 Leto release. It also states that later Pawnomics v3 and five-second search changes were web-only and not retroported. The release's weights and web tree are excluded.
- The active TonkAI checkout is at `C:\Users\Martim\Desktop\Github\TonkAI`, HEAD `f5405a9848c68f1a7d9804c80ffeabd8470bc47a`, branch `tonkai-page`, with pre-existing modified and untracked files. The attached current-source snapshot copies selected working-tree source without changing the checkout.
- The current `claudio/arena.py` exposes a process-pool game runner with `--workers` default 6; it imports `psutil_free_priority` in each worker. `claudio/groups.py` and `claudio/duel.py` build on the arena. `claudio/site_mutation.py` compares a CognitiveAgent mutation against a site-configured player and loads a checkpoint. These are source observations; their names alone do not prove that each is Martim's current G4 Leto mutation tournament.
- `scripts/evolve_tonkinho.py` evolves CognitiveAgent settings and uses spawned processes; its default checkpoint path is a cognitive-mix checkpoint. `scripts/match_engine.py` compares a checkpoint-based CognitiveAgent against a UCI engine. Include these as adjacent tournament code because Martim named them, but require proposals to distinguish them from the `claudio/` G4 Leto tournament path.
- The `releases/g4-leto` directory is a frozen snapshot dated 2026-10-14. Its Python source is reference material; this alone does not establish that the release checkpoint or release web engine is the local trained tournament target.
- No live benchmark, active process inspection, checkpoint comparison, or current mutation run was performed for this debate. Do not claim measured throughput or strength from source inspection.

## Scope

Include the local Python/C++ Leto and mutation-tournament paths under `claudio/`, the source-only Python reference under `releases/g4-leto/python/claudio/`, and the specifically named adjacent orchestration scripts `scripts/evolve_tonkinho.py` and `scripts/match_engine.py`. Identify which path actually evaluates a candidate mutation against the relevant baseline and what dependencies it uses.

For personalities, consider all ten deities in the earlier Pantheon request: Nezha, Loki, Wukong, Susanoo, Tsukuyomi, Anúbis, Amaterasu, Rá, Hades and Zeus. Propose computable move-selection signals and validation on the local Python/C++ engine. Do not use web-only personality visuals or code as the target.

Exclude the web engine, its WASM/binaries, site assets, the Council 005 plan/decree, all protected Gepeto sources, and all weights/checkpoints/data.

## Mandatory requirements

| R# | Requirement | How to verify |
| --- | --- | --- |
| R1 | Maximize completed mutation-tournament games per second on the confirmed Ryzen 5 7500F + RTX 5060 Ti. | Rank code-specific throughput levers, give estimate arithmetic and a combined target; distinguish estimates from measurements. |
| R2 | Preserve the decision quality/strength of the target engine and keep candidate comparisons valid. | Explain paired baselines, seeds/colours/openings, strength guardrails and how each optimization is proven equivalent or evaluated for loss. |
| R3 | Analyze the local Python/C++ engine and tournament path rather than the website. | Cite file/function evidence; explicitly map the current target and flag any path that actually uses a different CognitiveAgent or checkpoint. |
| R4 | Make all ten Pantheon styles observably distinct on the local target. | Give each deity concrete computable signals/parameters, define observability and compare against neutral Leto and each other. |
| R5 | Separate personality from intentional difficulty. | State how style changes while retaining strength; place any weaker level on a separate explicit axis. |
| R6 | Respect the current limit of at most six workers and low process priority. | Keep the proposal within both constraints or clearly recommend a change for Martim to decide; do not change runtime settings. |
| R7 | Do not launch or stop tournament/training jobs, benchmark the PC, or modify TonkAI during this Council phase. | Proposal/review only; no processes or source checkout are changed. |
| R8 | Apply Law No. 4 to participant availability. | Skip quota/credit/bug failures, record observed error, continue with responders; late answers are addenda. |

## Criteria in priority order

| Priority | Criterion | How to compare or measure |
| --- | --- | --- |
| 1 | Valid completed games per second | Define exactly what counts as a completed tournament game, include setup/teardown and persistence cost where relevant, compare same workload and hardware. |
| 2 | Strength and comparison validity | Use paired seeds/colours and fixed baselines; account for decision changes, mutation-selection bias and uncertainty. |
| 3 | Ten distinct, recognizable styles | Measure move/style signatures and distinguish every deity from neutral and the other nine. |
| 4 | Worker/priority safety | Stay within six workers and low priority unless the proposal clearly requests Martim to change the constraint. |
| 5 | Reversibility and evidence | Make proposed changes separable and benchmarkable; identify CPU/GPU utilization, memory and bottlenecks that remain unknown. |

## Proposal contents

Each proposal must:

1. Identify the exact active Python/C++ tournament path using the supplied files, and distinguish it from the frozen release reference and any CognitiveAgent-based adjacent scripts.
2. Rank code-specific games-per-second levers by expected gain, citing file/function, mechanism, decision changes, prerequisites and arithmetic labelled as an estimate.
3. Give a combined theoretical target for this Ryzen 5 7500F + RTX 5060 Ti, clearly separating theoretical estimates from any unsupported measurement.
4. Define an evaluation that preserves mutation comparison validity and checks strength, including paired seeds/colours and an uncertainty method.
5. Give all ten deities a concrete local-engine style: signals, initial parameters, bounded move-selection effect, guards for forced wins/defences and tactical safety, and checks for visible distinctness and strength retention.
6. Keep style separate from explicit difficulty, respect six workers/low priority, and identify any constraint change as a decision for Martim.

## Evidence available

- Direct sovereign instruction in this debate for target platform, local Python/C++ scope, all available participants, and six-worker/low-priority constraint.
- `claudio/ESTADO.md` and the specific source files listed in `CODE-INVENTORY.md`, copied from the dirty working tree at the recorded HEAD.
- `releases/g4-leto/README.md` and the source-only Python/C++ reference snapshot.
- No performance result has been generated in this phase. Claims about speed, GPU use, strength, personality outcomes or current active command remain unknown unless directly supported by included source.

## Open questions

No further sovereign decision is needed to start proposals. The exact active command/checkpoint used in Martim's current tournament is not yet established by the source snapshot; proposals must state what evidence would identify it and avoid silently assuming one. Proposals may recommend a minimal later read-only inventory, but must not launch a job or inspect excluded data during this phase.

## Participants

All available Council advisers are requested: Sol, GPT-6 Normal, Argon, Sonnet and Astra. The operator checks availability by dispatch and applies Law No. 4 to quota/credit/bug failures. Opus is King and synthesizes; it is not a proposal participant. Sol participates as an adviser and declares this in the manifest.

## Expected result

The King issues a reasoned plan and decree for the local Python/C++ mutation-tournament pipeline and ten local personalities. No benchmark, training, tournament, implementation or public release is performed before that decree and any later authorization.

---

## MANIFESTO.md

# Manifest — Local Leto mutation-tournament throughput and personalities, fresh cycle

- **Debate:** 007-leto-personalidades-jogos.
- **Date:** 2026-10-17 Europe/Lisbon.
- **Context:** `CONTEXTO.md` v3; local Python/C++ target, source-only package and constraints as recorded there.
- **Governance:** root `LEIS.md` Laws No. 1–4 and `REGRAS.md` v2.1 embedded in each packet.
- **Source package:** `PACOTE-PROPOSTA-v3.zip`; source inventory is inside; package digest in `PACOTES.sha256`.
- **Proposal marker:** `END-OF-PACKET-007-PROPOSAL-v3`.
- **Review packet:** prepared only after closure of the proposal set.
- **No GitHub publication, benchmark, tournament, training, account change or source implementation.**
- **Protected exclusions:** no `scripts/group_stage.py`, `Gepeto/`, weights, checkpoints, binaries, tournament outputs, credentials, tokens or `.env`.

## Independence and roles

All requested advisers are Sol, GPT-6 Normal, Argon, Sonnet and Astra; Opus is King, not a participant. Prior 007 proposals/reviews are historical and are excluded from the new closed sets. Sol is both operator and disclosed adviser; it has prior exposure to old 007 materials and will declare that. Every other contribution records model visibility, actual tools, memory, exposure and whether it is a new conversation/execution. All proposals use the same packet. No peer proposal is shared before closure.

## Availability rule

Attempt all five requested advisers anew for each phase. Under Law No. 4, immediately skip a participant on quota/credit absence or UI/CLI/model bug, recording the participant, phase, interface, timestamp and exact error. Do not wait, substitute or ask Martim to decide. A late contribution remains an addendum outside the closed set.

## Proposal receipts

| ID | Interface/session | Status | Receipt / error |
|---|---|---|---|
| sol | Pending | Pending | Pending |
| normal | Pending | Pending | Pending |
| argon | Pending | Pending | Pending |
| sonnet | Pending | Pending | Pending |
| astra | Pending | Pending | Pending |

---

## SOURCE-INVENTORY-v2.md

# Council 007 source inventory v2

Source-only copy for local Python/C++ engine and tournament analysis. No source checkout was modified.

- TonkAI working tree: branch `tonkai-page`, HEAD `f5405a9848c68f1a7d9804c80ffeabd8470bc47a`, dirty at capture. Copies current working bytes for selected source files.
- Frozen G4 Leto Python reference: `releases/g4-leto/python/claudio/` within the same checkout. The release README describes it as a Python reference associated with the G4 release; it is not asserted to be the active tournament binary.

## Included files

| Package path | Bytes | SHA-256 |
| --- | ---: | --- |
| `release-python/claudio/abertura_v1_original.py` | 18359 | `79549b0b9aed914c6cfa40d8f984374922f9b741b7a4bca1ba239e65c70e4e35` |
| `release-python/claudio/abertura.py` | 41016 | `cb6548f3ae4695c24148e581ef5570187d703ce7c6052234f1a8e350485ac0e6` |
| `release-python/claudio/base/scripts/evolve_tonkinho.py` | 14299 | `aff3094d334f932463e20864ff09446bbc9763757c4a1103f1555cda19d038c8` |
| `release-python/claudio/base/scripts/match_checkpoints.py` | 13709 | `9d28869bfb9d12090c9a9ae1e73a6992f441f337d61ed4515373924f99199eb5` |
| `release-python/claudio/base/setup_claudio.py` | 516 | `b5f83655a236d23c017b4be3ea8dfb0f50b240c8610f106da0236bdf99217bbc` |
| `release-python/claudio/base/tonkai_fast/fast.cpp` | 76684 | `4ae2984d06ae90dc0117ecf4e4516efb3551af4f8ef9a98939d5963cd1922204` |
| `release-python/claudio/base/tonkai/__init__.py` | 2202 | `6c9b3382029a8d459e4891ba11f3c0452b957cebd14361d541f63346788905a2` |
| `release-python/claudio/base/tonkai/actor_snapshot.py` | 1169 | `e67a0e069bb0c5e1e27eccd426a7524d16007be92e8802d45302fb567498d62a` |
| `release-python/claudio/base/tonkai/agent.py` | 15003 | `05edbda7b525aed1ca9caf59421a6029fde36b5d799c98b15b831e724cb44733` |
| `release-python/claudio/base/tonkai/captures.py` | 32925 | `92a9e303767519ac1407c21451e6a1ab5936963a22a42193c0c50c75a22839f3` |
| `release-python/claudio/base/tonkai/chess_env.py` | 2964 | `7539cf96aba262891d8ae01336adfd3ac05a249cfa29a7a6c564511d9b5ee76f` |
| `release-python/claudio/base/tonkai/cognitive_agent.py` | 65656 | `c63e0ad348d2d425a541f81d78bd9c20797058a3b82e3acdb8e8b54c1a5586c4` |
| `release-python/claudio/base/tonkai/cognitive_config.py` | 16945 | `307d935c432702ce05da54be6af1a44f04adca28b920619aab9bf72e4aac5fc0` |
| `release-python/claudio/base/tonkai/cognitive_memory.py` | 12742 | `8508ebb0412d9d976985e2a2a46ec6068a6dbb1c390633fefd68c0cec35d2426` |
| `release-python/claudio/base/tonkai/cognitive_pool.py` | 8890 | `fc1018d79fe505e9f4df54bb1836e092bceb59d02e3e0f0b59bae517386c6106` |
| `release-python/claudio/base/tonkai/cognitive_trainer.py` | 13874 | `c7e35720ef724d049a44c06ba27a8ab7c22c2423fd988c28efd6ef352a88e000` |
| `release-python/claudio/base/tonkai/config.py` | 4236 | `7b7dd55aa2818ac427c443b686988720ec2263cd15fd60973720e1f1afa3796b` |
| `release-python/claudio/base/tonkai/cuda_learner.py` | 3040 | `06b5525d7752d9cb0fb06be5f9e3f5daebfa2ee2584f698e4664b33289ee610f` |
| `release-python/claudio/base/tonkai/curriculum.py` | 4633 | `72e751f039d04a0c0a3f6928086e4552ea61979ac7bff4854c28385b2d4e182a` |
| `release-python/claudio/base/tonkai/encoding.py` | 7338 | `757207b2a6638d2476c06f0b0c27f4c7dc637b0e1288beafae8d540201552e04` |
| `release-python/claudio/base/tonkai/exchange.py` | 2258 | `5aa6ce5779d57d402190acea01f84c1ae8a609f648a1446a6d2b896ecb468971` |
| `release-python/claudio/base/tonkai/execution_fastpaths.py` | 2278 | `dc740481615fe3e65cf26816b36cd22ca8c9a41439232217e3e3ef2deb9e8a50` |
| `release-python/claudio/base/tonkai/fast_rules.py` | 3684 | `c4c716beb166d6ebf247c566f27f7999aec14d53b8481af4f7006330d5a049a3` |
| `release-python/claudio/base/tonkai/history.py` | 1295 | `8fa3a8a87d644cdfb29c411e0b93a460b59358d57afb0a2346918b362370cb2b` |
| `release-python/claudio/base/tonkai/inference_broker.py` | 4493 | `057c74a49ffed65034f8e4bbea74f32983c2fcc40b53a33d8ac6fe7f4bad9845` |
| `release-python/claudio/base/tonkai/king_safety_model.py` | 4909 | `4bdd0f8baf8cfea12e32eea356be84dd45bb2c783d434c5577da233ffffea365` |
| `release-python/claudio/base/tonkai/king_safety_training.py` | 17515 | `82a931d781e2077a5c7f6f29d259c3343d0a33f93b63b02364a3615206e68f43` |
| `release-python/claudio/base/tonkai/king_safety.py` | 4825 | `ba292d12b0d11c9a010b5bf4f5816ebb36a024be9fd20224dc35e887d3a34ff4` |
| `release-python/claudio/base/tonkai/metrics.py` | 7607 | `a0f2244287e961c7d0b3241b28ba65d923f18a81445f8bfc4ee8241c06e69db2` |
| `release-python/claudio/base/tonkai/model.py` | 4649 | `928128b3514463c50a7b2231e96298d36033fbc5720f2e84bc27614123706ebb` |
| `release-python/claudio/base/tonkai/network_fastpaths.py` | 3870 | `177cc831a7dca9349f93b247875a69407a07b425e5408109404dce5a2c93daab` |
| `release-python/claudio/base/tonkai/objective.py` | 3564 | `a9d863a9d2fff7e4159310c74536195e3e75bc3789d47bf18be23d84f2ff82b5` |
| `release-python/claudio/base/tonkai/opening_history.py` | 3162 | `55a52c5af84a37d16111a7dd4e601e8699282648e52ffcd41b8bb6bc61792e98` |
| `release-python/claudio/base/tonkai/opponents.py` | 3157 | `e98083faac8538138994b542232e067861d9cc5d1fd446b01120a26207797c3a` |
| `release-python/claudio/base/tonkai/parallel.py` | 6468 | `486e5af1eae61fedb8bde0174eb755e27b96ccd513252d4a8086f3c3293df3ac` |
| `release-python/claudio/base/tonkai/piece_safety.py` | 10183 | `a87f38e5f821ca7dcef3dece9379082afe72c83ee905490af0687b84c35689fa` |
| `release-python/claudio/base/tonkai/population.py` | 7015 | `f7435047388813d0d23b733e49755bd3d716c7479252e0c6cdfda6bd5779bdf3` |
| `release-python/claudio/base/tonkai/replay.py` | 4934 | `3e8252344dffd26cde96eefa0cdb9206c8939bf77e30220952c574682f2e206a` |
| `release-python/claudio/base/tonkai/resign.py` | 17508 | `78d0f77a80b2b2ead4adf12acfde547f3feec515dcdd4cd7ec6e2b1809037afb` |
| `release-python/claudio/base/tonkai/sequence_replay.py` | 17050 | `6dffbe4440fe4d62e30621cf8cd1ccaae2b20257283d3b5dc71c38f94e82e554` |
| `release-python/claudio/base/tonkai/survival_agent.py` | 13394 | `98b2781876b121c71ea3d68f0474108d78e3d8c29dff3394ae5dc9f319065984` |
| `release-python/claudio/base/tonkai/survival_config.py` | 3000 | `79595dc39b8f0650d3d04c008e1e9733dccf7f4d24ed206b9517ec985a830b5c` |
| `release-python/claudio/base/tonkai/survival_pool.py` | 12170 | `faba2133f1e451d91d8494e3907a6547246e0baeb968460899d7fb6eab75b2f5` |
| `release-python/claudio/base/tonkai/survival_trainer.py` | 27113 | `3c050e12b18e1f4d7f31629dff1f2c5d461121702d5078961b280a393d788418` |
| `release-python/claudio/base/tonkai/tablebase.py` | 1540 | `1695759e8f1e8d1f54741bce7b12950e3c68ab3ae5283744ecbbcb0e2d5f9f85` |
| `release-python/claudio/base/tonkai/temporal_model.py` | 9829 | `ce36467d7f5c079103db30c9a746b3da2594d8bd65d3c8d702b792012089af42` |
| `release-python/claudio/base/tonkai/theory_buffer.py` | 3458 | `8c0c1f27a59501352eb42079f75e25b432d85dd640acf6fdcadcb50e1d36f109` |
| `release-python/claudio/base/tonkai/trainer.py` | 11060 | `cd41c2a3daa68134b2a325220c77a3dee27bfc645a191518bf36d9bb42ee8a1a` |
| `release-python/claudio/base/tonkai/uci_opponent.py` | 6813 | `68b4abb83558910a58d1d7645f92487cda45373a9bd5ee14d26d141875d3c6a7` |
| `release-python/claudio/base/tonkai/web_publish.py` | 2523 | `d92ac40c83214ff3c881d75dfa6d1b97d3ce654c4a904d412832e930fa8730a7` |
| `release-python/claudio/base/tonkai/win_history.py` | 16364 | `5f338ce24759e8e883b07961bb3fb787ed3125fd40147ceff4848a061b676658` |
| `release-python/claudio/claudio_agent.py` | 50763 | `31aedceb35b42a7f4be497f2f7e18716179c045543ddba6c37ed695325b13481` |
| `release-python/claudio/claudio_load.py` | 3772 | `c1c276e82366162f9370b33a25e8d14531f8be5378f3ce3b39b03dbcceaef689` |
| `release-python/claudio/claudio_net.py` | 4132 | `0796d8e58bebfacf00e5f042d4502e02dbbec6a64203c458426d6e03627d83f3` |
| `release-python/claudio/fast/claudio_fast.cpp` | 108075 | `99b14a41b186434973e7770c854db8d7ddc1b7e3d9dd9b8868bb351227cc89db` |
| `release-python/claudio/fast/setup.py` | 954 | `06d6d25ee0f00a3928306ea90b30b58cd149a92c90c77948000bace52d8a77cc` |
| `release-python/claudio/paths.py` | 1259 | `1e9bc23a0ec5a84244132c4ba8c04fdb7acbb80e53e63f0490b84c5562bf2550` |
| `release-python/claudio/pawnomics.py` | 10034 | `02d29d67ab94561cf9b2b43719c2f1c2c7ab2b2b3194d74b7f0e24a55b2e2c6d` |
| `release-python/claudio/psutil_free_priority.py` | 260 | `3a349ea68c16575e0b105fe4d7daee803a24a59c89358c2f51380c31b69c7115` |
| `release-python/claudio/review.py` | 11943 | `a2f6d64bdde773e816bc340590b5b34a5941856934af85d993fad5e002ed6c55` |
| `release-python/claudio/test_abertura.py` | 15789 | `ae80e78f81932cb89ab52d4be84fe1e64c892dca94837d41afcc4fb084252c9c` |
| `release-python/claudio/test_claudio.py` | 11430 | `e2a7be40aa105c07f8f44c6e498201b53efe54c1c88d545222ea0c3a141bd556` |
| `release-python/claudio/testes-baseline/abertura.py` | 34112 | `6e1d53b597071b709c2a49af709afce1cdc348e5ae7b6684aad9ead9e0c59c69` |
| `release-python/claudio/testes-baseline/claudio_agent.py` | 48975 | `7bab08485f8505dd3587344036d6d41fed853794e651773ab5f9badf44161283` |
| `release-python/claudio/train_claudio.py` | 16661 | `4e1a2ee458273474482ed90bbe472a6611ab1fc80274855ce9a7f2c4275d1bc6` |
| `release-python/claudio/train_grande.py` | 51411 | `fdd4c90b207089445b7f85045e5b50fff1cfb67e200f0a95cbbabe45ee6a644c` |
| `release-python/claudio/uci.py` | 2707 | `609a1ad5a99d5efc9be41f3f77fca103dd84823c6c44e468e61cc98a41102177` |
| `working-tree/claudio/arena.py` | 8504 | `d0225bd76202883bf0e05600ddd60711a153a90c466f44b281b0aee4a974e54b` |
| `working-tree/claudio/base/scripts/evolve_tonkinho.py` | 14299 | `aff3094d334f932463e20864ff09446bbc9763757c4a1103f1555cda19d038c8` |
| `working-tree/claudio/base/scripts/match_checkpoints.py` | 13709 | `9d28869bfb9d12090c9a9ae1e73a6992f441f337d61ed4515373924f99199eb5` |
| `working-tree/claudio/base/tonkai_fast/fast.cpp` | 76684 | `4ae2984d06ae90dc0117ecf4e4516efb3551af4f8ef9a98939d5963cd1922204` |
| `working-tree/claudio/base/tonkai/__init__.py` | 2202 | `6c9b3382029a8d459e4891ba11f3c0452b957cebd14361d541f63346788905a2` |
| `working-tree/claudio/base/tonkai/actor_snapshot.py` | 1169 | `e67a0e069bb0c5e1e27eccd426a7524d16007be92e8802d45302fb567498d62a` |
| `working-tree/claudio/base/tonkai/agent.py` | 15003 | `05edbda7b525aed1ca9caf59421a6029fde36b5d799c98b15b831e724cb44733` |
| `working-tree/claudio/base/tonkai/captures.py` | 32925 | `92a9e303767519ac1407c21451e6a1ab5936963a22a42193c0c50c75a22839f3` |
| `working-tree/claudio/base/tonkai/chess_env.py` | 2964 | `7539cf96aba262891d8ae01336adfd3ac05a249cfa29a7a6c564511d9b5ee76f` |
| `working-tree/claudio/base/tonkai/cognitive_agent.py` | 65656 | `c63e0ad348d2d425a541f81d78bd9c20797058a3b82e3acdb8e8b54c1a5586c4` |
| `working-tree/claudio/base/tonkai/cognitive_config.py` | 16945 | `307d935c432702ce05da54be6af1a44f04adca28b920619aab9bf72e4aac5fc0` |
| `working-tree/claudio/base/tonkai/cognitive_memory.py` | 12742 | `8508ebb0412d9d976985e2a2a46ec6068a6dbb1c390633fefd68c0cec35d2426` |
| `working-tree/claudio/base/tonkai/cognitive_pool.py` | 8890 | `fc1018d79fe505e9f4df54bb1836e092bceb59d02e3e0f0b59bae517386c6106` |
| `working-tree/claudio/base/tonkai/cognitive_trainer.py` | 13874 | `c7e35720ef724d049a44c06ba27a8ab7c22c2423fd988c28efd6ef352a88e000` |
| `working-tree/claudio/base/tonkai/config.py` | 4236 | `7b7dd55aa2818ac427c443b686988720ec2263cd15fd60973720e1f1afa3796b` |
| `working-tree/claudio/base/tonkai/cuda_learner.py` | 3040 | `06b5525d7752d9cb0fb06be5f9e3f5daebfa2ee2584f698e4664b33289ee610f` |
| `working-tree/claudio/base/tonkai/curriculum.py` | 4633 | `72e751f039d04a0c0a3f6928086e4552ea61979ac7bff4854c28385b2d4e182a` |
| `working-tree/claudio/base/tonkai/encoding.py` | 7338 | `757207b2a6638d2476c06f0b0c27f4c7dc637b0e1288beafae8d540201552e04` |
| `working-tree/claudio/base/tonkai/exchange.py` | 2258 | `5aa6ce5779d57d402190acea01f84c1ae8a609f648a1446a6d2b896ecb468971` |
| `working-tree/claudio/base/tonkai/execution_fastpaths.py` | 2278 | `dc740481615fe3e65cf26816b36cd22ca8c9a41439232217e3e3ef2deb9e8a50` |
| `working-tree/claudio/base/tonkai/fast_rules.py` | 3684 | `c4c716beb166d6ebf247c566f27f7999aec14d53b8481af4f7006330d5a049a3` |
| `working-tree/claudio/base/tonkai/history.py` | 1295 | `8fa3a8a87d644cdfb29c411e0b93a460b59358d57afb0a2346918b362370cb2b` |
| `working-tree/claudio/base/tonkai/inference_broker.py` | 4493 | `057c74a49ffed65034f8e4bbea74f32983c2fcc40b53a33d8ac6fe7f4bad9845` |
| `working-tree/claudio/base/tonkai/king_safety_model.py` | 4909 | `4bdd0f8baf8cfea12e32eea356be84dd45bb2c783d434c5577da233ffffea365` |
| `working-tree/claudio/base/tonkai/king_safety_training.py` | 17515 | `82a931d781e2077a5c7f6f29d259c3343d0a33f93b63b02364a3615206e68f43` |
| `working-tree/claudio/base/tonkai/king_safety.py` | 4825 | `ba292d12b0d11c9a010b5bf4f5816ebb36a024be9fd20224dc35e887d3a34ff4` |
| `working-tree/claudio/base/tonkai/metrics.py` | 7607 | `a0f2244287e961c7d0b3241b28ba65d923f18a81445f8bfc4ee8241c06e69db2` |
| `working-tree/claudio/base/tonkai/model.py` | 4649 | `928128b3514463c50a7b2231e96298d36033fbc5720f2e84bc27614123706ebb` |
| `working-tree/claudio/base/tonkai/network_fastpaths.py` | 3870 | `177cc831a7dca9349f93b247875a69407a07b425e5408109404dce5a2c93daab` |
| `working-tree/claudio/base/tonkai/objective.py` | 3564 | `a9d863a9d2fff7e4159310c74536195e3e75bc3789d47bf18be23d84f2ff82b5` |
| `working-tree/claudio/base/tonkai/opening_history.py` | 3162 | `55a52c5af84a37d16111a7dd4e601e8699282648e52ffcd41b8bb6bc61792e98` |
| `working-tree/claudio/base/tonkai/opponents.py` | 3157 | `e98083faac8538138994b542232e067861d9cc5d1fd446b01120a26207797c3a` |
| `working-tree/claudio/base/tonkai/parallel.py` | 6468 | `486e5af1eae61fedb8bde0174eb755e27b96ccd513252d4a8086f3c3293df3ac` |
| `working-tree/claudio/base/tonkai/piece_safety.py` | 10183 | `a87f38e5f821ca7dcef3dece9379082afe72c83ee905490af0687b84c35689fa` |
| `working-tree/claudio/base/tonkai/population.py` | 7015 | `f7435047388813d0d23b733e49755bd3d716c7479252e0c6cdfda6bd5779bdf3` |
| `working-tree/claudio/base/tonkai/replay.py` | 4934 | `3e8252344dffd26cde96eefa0cdb9206c8939bf77e30220952c574682f2e206a` |
| `working-tree/claudio/base/tonkai/resign.py` | 17508 | `78d0f77a80b2b2ead4adf12acfde547f3feec515dcdd4cd7ec6e2b1809037afb` |
| `working-tree/claudio/base/tonkai/sequence_replay.py` | 17050 | `6dffbe4440fe4d62e30621cf8cd1ccaae2b20257283d3b5dc71c38f94e82e554` |
| `working-tree/claudio/base/tonkai/survival_agent.py` | 13394 | `98b2781876b121c71ea3d68f0474108d78e3d8c29dff3394ae5dc9f319065984` |
| `working-tree/claudio/base/tonkai/survival_config.py` | 3000 | `79595dc39b8f0650d3d04c008e1e9733dccf7f4d24ed206b9517ec985a830b5c` |
| `working-tree/claudio/base/tonkai/survival_pool.py` | 12170 | `faba2133f1e451d91d8494e3907a6547246e0baeb968460899d7fb6eab75b2f5` |
| `working-tree/claudio/base/tonkai/survival_trainer.py` | 27113 | `3c050e12b18e1f4d7f31629dff1f2c5d461121702d5078961b280a393d788418` |
| `working-tree/claudio/base/tonkai/tablebase.py` | 1540 | `1695759e8f1e8d1f54741bce7b12950e3c68ab3ae5283744ecbbcb0e2d5f9f85` |
| `working-tree/claudio/base/tonkai/temporal_model.py` | 9829 | `ce36467d7f5c079103db30c9a746b3da2594d8bd65d3c8d702b792012089af42` |
| `working-tree/claudio/base/tonkai/theory_buffer.py` | 3458 | `8c0c1f27a59501352eb42079f75e25b432d85dd640acf6fdcadcb50e1d36f109` |
| `working-tree/claudio/base/tonkai/trainer.py` | 11060 | `cd41c2a3daa68134b2a325220c77a3dee27bfc645a191518bf36d9bb42ee8a1a` |
| `working-tree/claudio/base/tonkai/uci_opponent.py` | 6813 | `68b4abb83558910a58d1d7645f92487cda45373a9bd5ee14d26d141875d3c6a7` |
| `working-tree/claudio/base/tonkai/web_publish.py` | 2523 | `d92ac40c83214ff3c881d75dfa6d1b97d3ce654c4a904d412832e930fa8730a7` |
| `working-tree/claudio/base/tonkai/win_history.py` | 16364 | `5f338ce24759e8e883b07961bb3fb787ed3125fd40147ceff4848a061b676658` |
| `working-tree/claudio/claudio_agent.py` | 18363 | `daa80d00aafc9eef2e898dfc82ea463a0afee4e97dc81b3fa495cd73108a93dc` |
| `working-tree/claudio/claudio_load.py` | 3299 | `b7d04548b9147df93d5496878d967b1910d73bb0ccab074b2a880fcdddae4dd2` |
| `working-tree/claudio/claudio_net.py` | 4037 | `f67a3253e0a02870a7cea2cb98afda9e06003c4973533400d26a1bbf543e89b1` |
| `working-tree/claudio/duel.py` | 8005 | `07cbce9e5c06fb6a807e18312f488acc110a75eaf7e054f7fc1c59dbc2dc9cba` |
| `working-tree/claudio/fast/claudio_fast.before-lazy.cpp` | 80158 | `1f7707285a3c0ee73e034fb7006ef53ea3d729cfae8965de223e6eab6e724861` |
| `working-tree/claudio/fast/claudio_fast.cpp` | 82463 | `62e08d7a6da3c9d36c21d415c8937973b1362f3fc4b68fff889b43f61a30ba71` |
| `working-tree/claudio/fast/setup.py` | 495 | `318f49b7d2851281d57c259fd68401884f9382b15fa189fbce3ff19a85dbfdbc` |
| `working-tree/claudio/groups.py` | 5836 | `373f68b4e14d8493d1abedb61be998654a65ba10aa2cad15edd39c1ed8999dd3` |
| `working-tree/claudio/paths.py` | 1259 | `1e9bc23a0ec5a84244132c4ba8c04fdb7acbb80e53e63f0490b84c5562bf2550` |
| `working-tree/claudio/profile_selfplay.py` | 3791 | `21eb33f9c108b27fc494fa9a19b6246d663b98606d9e056fbb0fba4fe03591fb` |
| `working-tree/claudio/psutil_free_priority.py` | 254 | `fb89301624eac84a57079bd46abcb46bb9aeea1a88da42d2d134a2164342b240` |
| `working-tree/claudio/site_mutation.py` | 6350 | `8ed5bbd5fa544413e9cd9749e6244771337754d38189237d357b5058388bfb2f` |
| `working-tree/claudio/time_claudio.py` | 1169 | `f2ec091b11f1f9c88e7537bcf80ef06fb28c9da402a6dfd3368bafbc6e98a40f` |
| `working-tree/scripts/evolve_tonkinho.py` | 14299 | `aff3094d334f932463e20864ff09446bbc9763757c4a1103f1555cda19d038c8` |
| `working-tree/scripts/match_checkpoints.py` | 13709 | `9d28869bfb9d12090c9a9ae1e73a6992f441f337d61ed4515373924f99199eb5` |
| `working-tree/scripts/match_engine.py` | 7142 | `b33d4ac69de549f3f585da106c80d8a1b0b099da893f8c4878e15840c3eb7bf8` |
| `working-tree/tonkai_fast/fast.cpp` | 76651 | `edf9b06d1088f734f3a337cb481dde33ab7a21ac6697d02fe5145d86127d8dfc` |
| `working-tree/tonkai/__init__.py` | 2202 | `6c9b3382029a8d459e4891ba11f3c0452b957cebd14361d541f63346788905a2` |
| `working-tree/tonkai/actor_snapshot.py` | 1138 | `1daf2b0b6d949cdd48518f1f2b3c273c773a3e9e2ee9785087f97aec25f9e6b3` |
| `working-tree/tonkai/agent.py` | 14996 | `72157d69ade8a8ba45166b42e2dfa846727a71d67f68f7ca26ecd1b1ee8c26f9` |
| `working-tree/tonkai/captures.py` | 35080 | `8683bc7a1690294252263653bac3469b08356e3d51bea3616747ab2429c62c8c` |
| `working-tree/tonkai/chess_env.py` | 2876 | `6135af0fdf14da2c019250390aaf4656ca5c7abcfb07fbb4d771e3703003df10` |
| `working-tree/tonkai/cognitive_agent.py` | 65646 | `35a5d210adb2e242752d9a9688776a5750c75580f0ad5a2862489391c7043e42` |
| `working-tree/tonkai/cognitive_config.py` | 17235 | `d8284c14d95b032bc077d18e03a12fc720afc053539347a4f4af47ca1850a77e` |
| `working-tree/tonkai/cognitive_memory.py` | 12742 | `8508ebb0412d9d976985e2a2a46ec6068a6dbb1c390633fefd68c0cec35d2426` |
| `working-tree/tonkai/cognitive_pool.py` | 8890 | `fc1018d79fe505e9f4df54bb1836e092bceb59d02e3e0f0b59bae517386c6106` |
| `working-tree/tonkai/cognitive_trainer.py` | 14097 | `5659541ede66168ba124dccab1726aebe981281f79b044602b21ede9e405e2a7` |
| `working-tree/tonkai/config.py` | 4234 | `2f5cfb932efbc390f6f80b59c61c59816918e54b01683799bb198fb235362924` |
| `working-tree/tonkai/cuda_learner.py` | 3040 | `06b5525d7752d9cb0fb06be5f9e3f5daebfa2ee2584f698e4664b33289ee610f` |
| `working-tree/tonkai/curriculum.py` | 4521 | `97f187055f9b3aede6b18fc5d3245d1b765f60e9df94cc32542c94d42046ae36` |
| `working-tree/tonkai/encoding.py` | 7305 | `0eec3af89c0d0707bdbdc6d46c3c59ef91e1ae0a797f18a1f1b2cc44d45c3900` |
| `working-tree/tonkai/exchange.py` | 2192 | `b51ea8ec5e13108c53760e487a3db347136108e20ae44fac3d1bf408e03fb5a7` |
| `working-tree/tonkai/execution_fastpaths.py` | 2229 | `b30c51dc690e4196f9edcf990d748b3307ce0cfa5b2341b8d36bbdfdc74ee4c4` |
| `working-tree/tonkai/fast_rules.py` | 3684 | `c4c716beb166d6ebf247c566f27f7999aec14d53b8481af4f7006330d5a049a3` |
| `working-tree/tonkai/history.py` | 1268 | `3a62d42ae6a2f57f5dbbe95e15acd57ef37d97f76e45e44719a57b144e324207` |
| `working-tree/tonkai/inference_broker.py` | 4381 | `24d387749570a94ad8a0a4b5e4165c50b8928a2c74432ec9bb62af5b174926d2` |
| `working-tree/tonkai/king_safety_model.py` | 4909 | `4bdd0f8baf8cfea12e32eea356be84dd45bb2c783d434c5577da233ffffea365` |
| `working-tree/tonkai/king_safety_training.py` | 17515 | `82a931d781e2077a5c7f6f29d259c3343d0a33f93b63b02364a3615206e68f43` |
| `working-tree/tonkai/king_safety.py` | 4733 | `a2b52c70c6af6d27eda0f6fcee5161625f3fdfa379d4ab7c37b9fbc8a61f7ef7` |
| `working-tree/tonkai/metrics.py` | 7607 | `a0f2244287e961c7d0b3241b28ba65d923f18a81445f8bfc4ee8241c06e69db2` |
| `working-tree/tonkai/model.py` | 4515 | `7acc038b32fa6bc5cdff778a89e7e03d3fe6676c76809f8a96a03d617488c451` |
| `working-tree/tonkai/network_fastpaths.py` | 3782 | `41f4dc2cb4c47bfeb849aaac5f94ff6a24923e95a94113dd8415e4ffccc03522` |
| `working-tree/tonkai/objective.py` | 3564 | `a9d863a9d2fff7e4159310c74536195e3e75bc3789d47bf18be23d84f2ff82b5` |
| `working-tree/tonkai/opening_history.py` | 3098 | `a5e95b67a9e6e8f0b0370d0c246b2959dc124c69624c3851d1646daf67f72271` |
| `working-tree/tonkai/opponents.py` | 3073 | `ff3eb22f8936c06a0bbd6db192c007cd7b56121a5226c70bbb2561125cd1b84a` |
| `working-tree/tonkai/parallel.py` | 6326 | `477bfceea59d5bc52a1778bd8ef457df7d11d72b71bc472958c685f2d3ce6f0c` |
| `working-tree/tonkai/piece_safety.py` | 10183 | `a87f38e5f821ca7dcef3dece9379082afe72c83ee905490af0687b84c35689fa` |
| `working-tree/tonkai/population.py` | 6858 | `ee20c12cb9197cf4d78d0f9b8675dd49888a11a272d949a454f4ecd9933ce678` |
| `working-tree/tonkai/replay.py` | 4934 | `3e8252344dffd26cde96eefa0cdb9206c8939bf77e30220952c574682f2e206a` |
| `working-tree/tonkai/resign.py` | 17438 | `931516ff9f202ce079f146741fe769b8a970bb7695d98f5ed1b54b4958c28bde` |
| `working-tree/tonkai/sequence_replay.py` | 16749 | `05c891ec4e2720269a73528410a9ac74309f5b1596fbb7c8233d6d384fe38067` |
| `working-tree/tonkai/survival_agent.py` | 13394 | `98b2781876b121c71ea3d68f0474108d78e3d8c29dff3394ae5dc9f319065984` |
| `working-tree/tonkai/survival_config.py` | 3000 | `79595dc39b8f0650d3d04c008e1e9733dccf7f4d24ed206b9517ec985a830b5c` |
| `working-tree/tonkai/survival_pool.py` | 11885 | `ead2f1ffb0e440a07b9b14c150cc78640620b3086a0ac06351e30b00d60b8a92` |
| `working-tree/tonkai/survival_trainer.py` | 29105 | `c8b05421a59c517184f4d66497a0c58ab2e2259c771ec71fa928396b534bad18` |
| `working-tree/tonkai/tablebase.py` | 1494 | `fb96487005b0dd100917566a2766180384e26adce6aa0fc9eab10886aa3a69ba` |
| `working-tree/tonkai/temporal_model.py` | 9829 | `ce36467d7f5c079103db30c9a746b3da2594d8bd65d3c8d702b792012089af42` |
| `working-tree/tonkai/theory_buffer.py` | 3346 | `0cd253346e75c2f88ebb8122fbcb933c41dbf2d314d5097582e2940b11a39125` |
| `working-tree/tonkai/trainer.py` | 11034 | `d7fb199ca0cbd0a8826caf6d43b0d5fbd531d48be4e514084f5a73f7423296e0` |
| `working-tree/tonkai/uci_opponent.py` | 6658 | `097c4dfd4e7bf8d0fa262fc910d46ace0e8a005edc8ee8f98fd2d1ef2bda3ef8` |
| `working-tree/tonkai/web_publish.py` | 2473 | `fa3f1e3e672ed0aad986178bcb4b4bb81e2bcfc0d5346ba1a2daf22972b74b36` |
| `working-tree/tonkai/win_history.py` | 16364 | `5f338ce24759e8e883b07961bb3fb787ed3125fd40147ceff4848a061b676658` |

## Exclusions

- Excluded all web source and assets, model weights/checkpoints, compiled binaries/extensions, data/results/logs, credentials, tokens and `.env` files.
- Did not read or copy `scripts/group_stage.py` or any `Gepeto/` source.
- No JSON tournament outputs, opening-book data, WASM, `.pt`, `.bin`, `.pyc` or `.pyd` files are included.

---

## templates/CONTRIBUICAO.md

<end marker received> | Missing sections: <list or none>

# <Proposal or review> — <participant>

- **Participant:** <ID>
- **Visible model:** <Exact label or not visible.>
- **Date:** <YYYY-MM-DD>
- **Phase and round:** <Phase / round.>
- **Context version:** <Version.>
- **Reference commit:** <Commit or not supplied.>
- **Files received and read:** <List both; identify any partial or unread file.>
- **Tools used:** <Tools actually used or none.>
- **Cross-conversation memory:** <Available memory and its use, or none.>
- **Prior exposure:** <Material from this debate already seen or authored, or none.>
- **New conversation:** <Yes / no.>
- **Access limits:** <Unavailable files, sources or tools, or none.>

## Brief — up to 300 words

<Recommendation, decisive reasons, main alternative, failure condition and how to check it.>

## Analysis

<Use the sections and tables required by the phase's prompt. Reference R# and U# where they affect the decision.>

## Evidence and assumptions

| Decisive claim | State | Provenance and passage | Phase | Scope |
| --- | --- | --- | --- | --- |
| <Claim.> | <supported / attributed / assumption / contested / unknown> | <File and passage, source or test.> | <When consulted.> | <What this establishes and its limits.> |

## Risks and checks

<Concrete consequences, failure conditions, checks and results that would change the recommendation.>

END-OF-CONTRIBUTION

---

## prompts/01-PROPOR.md

# Prompt 1 — Independent proposal

**For the operator — the Right Hand (Codex 6.1 Sol xHigh).** Open a new conversation for each participant. Send the same `PACOTE-PROPOSTA.md` to everyone. It contains, in order: the section list, `LEIS.md`, `REGRAS.md`, `CONTEXTO.md`, the manifest, `templates/CONTRIBUICAO.md`, the text below, and the end marker on the last line. Do not include other participants' proposals. Before the packet, add only the line `Participant ID: <id>.` Record any other addition in the manifest. If the Right Hand also participates, the manifest says so. Keep the answers outside the repository until the round closes.

---

You are a participant in a Council that must produce a plan for the decision described in CONTEXTO.md. Follow LEIS.md first, then REGRAS.md. Martim alone makes the Laws and may overrule. The King (Opus) synthesizes and decrees. The Right Hand operates and implements. You propose and review; you do not decide. Do not debate Law No. 2. Do not implement anything.

On the first line, repeat the packet's end marker and list any missing sections, or write «Missing sections: none». If the marker is missing or wrong, ask for the packet again instead of proposing.

Use templates/CONTRIBUICAO.md. Declare your participant ID, the visible model (or «not visible»), the tools you actually used, cross-conversation memory, prior exposure to this debate, and whether this is a new conversation. Do not look for other participants' proposals.

Your answer must contain:

1. A brief of up to 300 words: recommendation, decisive reasons, the main alternative, the condition under which it fails, and how to check it.
2. Your reading of the objective, the requirements (R#) and the open questions (U#) that could change the decision.
3. The recommended plan: components, responsibilities, interfaces, flow and execution steps with observable acceptance checks.
4. At least one plausible alternative, and why you prefer your recommendation.
5. A comparison against the context's requirements and criteria.
6. Risks, failure modes and dependencies. List every risk that could break a mandatory requirement.
7. Evidence table for decisive claims: state (supported, attributed, assumption, contested, unknown), provenance and passage, scope, and the phase in which you consulted it.
8. At least one refutation test: the observable result that would make you abandon or change the recommendation.

Apply Law No. 1: analyze time or resource metrics only when they belong to Martim's explicitly stated objective or constraints; do not invent personal limits, spending authority, deadlines or resource targets. Do not invent tools, research or results. Write in English, in Markdown. End your answer with a line containing only `END-OF-CONTRIBUTION`.

---

## Fixed additions and exclusions

- Participant-specific addition: `Participant ID: <id>.`
- Analyze only the supplied local Python/C++ source and tournament paths. Do not consult excluded website code or infer protected code behavior.
- Do not read or include `scripts/group_stage.py` or any `Gepeto/` source. No weights, checkpoints, model binaries, results/data, credentials, tokens or `.env` files are included.
- No benchmark, tournament, training, implementation or public release is authorized by this proposal packet. Label projections as estimates.

## END MARKER

END-OF-PACKET-007-PROPOSAL-v3
